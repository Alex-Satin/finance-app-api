export interface User {
    name: string;
    createdAt: Date;
    id: string;
    email: string;
  }
  