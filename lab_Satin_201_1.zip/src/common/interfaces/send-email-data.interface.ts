export interface SendEmailData {
  to: string;
  subject: string;
  text: string;
}
