export interface Account {
  name: string;
  currency: string;
  userId: string;
  createdAt: Date;
  id: string;
}
