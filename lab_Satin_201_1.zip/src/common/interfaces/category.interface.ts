export interface Category {
    name: string;
    createdAt: Date;
    id: string;
    imageUrl: string;
  }
  