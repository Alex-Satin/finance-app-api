import { TokensService } from './tokens.service';

export * from './tokens.service';

export const SERVICES = [TokensService];
