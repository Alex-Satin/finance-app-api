export enum GoogleDriveFolders {
  AVATARS = 'avatars',
}
