export enum RegularPaymentInterval {
  EVERY_DAY = 'EVERY_DAY',
  EVERY_MONTH = 'EVERY_MONTH',
}
