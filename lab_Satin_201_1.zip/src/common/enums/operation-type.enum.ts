export enum OperationType {
  INCOME = 'INCOME',
  OUTGO = 'OUTGO',
}
