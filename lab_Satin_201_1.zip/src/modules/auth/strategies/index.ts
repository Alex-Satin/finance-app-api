import { JwtStrategy } from './jwt.strategy';

export const STRATEGIES = [JwtStrategy];

export { JwtStrategy };
