import { WebSocketGateway, WebSocketServer, OnGatewayConnection, OnGatewayDisconnect, SubscribeMessage } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

@WebSocketGateway()
export class WebsocketGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  handleConnection(client: Socket) {
    // Логика при подключении клиента
  }

  handleDisconnect(client: Socket) {
    // Логика при отключении клиента
  }

  @SubscribeMessage('data')
  handleData(client: Socket, payload: any) {
    // Логика обработки данных от клиента
    // Отправка данных на клиентские сокеты
    this.server.emit('data', payload);
  }
}
