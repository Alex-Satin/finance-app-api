export enum OperationType {
  INCOME = 'income',
  OUTGO = 'outgo',
}
